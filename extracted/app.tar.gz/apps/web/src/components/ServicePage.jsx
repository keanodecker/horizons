
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { subscribeToContent, getContent } from '@/lib/supabaseContent.js';

const ServicePage = ({ serviceId, title: defaultTitle, description: defaultDescription, heroImage: defaultHeroImage }) => {
  const [content, setContent] = useState({
    title: defaultTitle,
    description: defaultDescription,
    heroImage: defaultHeroImage
  });

  useEffect(() => {
    const unsubscribe = subscribeToContent(() => {
      setContent({
        title: getContent(`${serviceId}_title`, defaultTitle),
        description: getContent(`${serviceId}_description`, defaultDescription),
        heroImage: getContent(`${serviceId}_image`, defaultHeroImage),
      });
    });
    return () => unsubscribe();
  }, [serviceId, defaultTitle, defaultDescription, defaultHeroImage]);

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      <Helmet>
        <title>{content.title} - Ballonkunst Herzog Lahr</title>
        <meta name="description" content={content.description} />
      </Helmet>

      {/* Hero Section */}
      <section className="relative h-[50vh] min-h-[400px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src={content.heroImage}
            alt={content.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
        </div>

        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-bold mb-6 drop-shadow-lg"
          >
            {content.title}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl md:text-2xl max-w-3xl mx-auto drop-shadow-md text-gray-100"
          >
            {content.description}
          </motion.p>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">
            Individuelle {content.title} Dekoration
          </h2>
          <p className="text-lg text-gray-700 leading-relaxed mb-8">
            Jeder Anlass ist einzigartig, und so sollte auch die Dekoration sein. 
            Wir gestalten Ihre Ballondekoration ganz nach Ihren persönlichen Wünschen 
            und Vorstellungen. Kontaktieren Sie uns für eine individuelle Beratung!
          </p>
        </div>
      </section>
    </div>
  );
};

export default ServicePage;
