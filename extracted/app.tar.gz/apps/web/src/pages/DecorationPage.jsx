
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { subscribeToContent, getContent } from '@/lib/supabaseContent.js';

const DecorationPage = () => {
  const { toast } = useToast();
  const [content, setContent] = useState({
    dekoration_title: 'Dekoration & Produkte',
    dekoration_description: 'Von klassischen Ballons bis zu kreativen Geschenkideen – entdecken Sie unsere vielfältige Produktpalette',
    dekoration_image: ''
  });

  useEffect(() => {
    const unsubscribe = subscribeToContent(() => {
      setContent({
        dekoration_title: getContent('dekoration_title', 'Dekoration & Produkte'),
        dekoration_description: getContent('dekoration_description', 'Von klassischen Ballons bis zu kreativen Geschenkideen – entdecken Sie unsere vielfältige Produktpalette'),
        dekoration_image: getContent('dekoration_image', '')
      });
    });
    return () => unsubscribe();
  }, []);

  const products = [
    { emoji: '🎨', title: 'Ballondekorationen', description: 'Professionelle Ballondekorationen für Events, Feiern und besondere Anlässe.', color: 'from-pink-400 to-purple-400' },
    { emoji: '🎁', title: 'Geschenkballons', description: 'Personalisierte Geschenkballons mit individuellen Botschaften.', color: 'from-blue-400 to-cyan-400' },
    { emoji: '📦', title: 'Ballonboxen', description: 'Überraschungsboxen gefüllt mit bunten Ballons.', color: 'from-yellow-400 to-orange-400' },
    { emoji: '💐', title: 'Ballonsträuße', description: 'Wunderschöne Ballonsträuße in verschiedenen Farben und Designs.', color: 'from-pink-300 to-red-400' },
    { emoji: '⭐', title: 'Folienballons', description: 'Hochwertige Folienballons in vielen Formen und Motiven.', color: 'from-purple-400 to-pink-400' },
    { emoji: '🎈', title: 'Latexballons', description: 'Klassische Latexballons in allen Farben des Regenbogens.', color: 'from-green-400 to-teal-400' },
  ];

  const handleCTA = () => {
    toast({
      title: '🚧 Diese Funktion ist noch nicht verfügbar',
      description: 'Bitte besuchen Sie uns im Geschäft oder rufen Sie uns an!',
    });
  };

  return (
    <>
      <Helmet>
        <title>{content.dekoration_title} - Ballonkunst Herzog Lahr</title>
        <meta name="description" content={content.dekoration_description} />
      </Helmet>

      <div className="pt-20">
        {/* Hero Section */}
        <section 
          className="relative py-32 bg-gradient-to-br from-pink-50 via-blue-50 to-yellow-50 overflow-hidden"
          style={content.dekoration_image ? { backgroundImage: `url(${content.dekoration_image})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}
        >
          {content.dekoration_image && <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-0"></div>}
          
          <div className="relative container mx-auto px-4 max-w-7xl text-center z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
                {content.dekoration_title}
              </h1>
              <p className="text-xl md:text-2xl text-gray-700 max-w-3xl mx-auto leading-relaxed whitespace-pre-wrap">
                {content.dekoration_description}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 max-w-7xl">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map((product, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.05 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                  className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden group"
                >
                  <div className={`h-48 bg-gradient-to-br ${product.color} flex items-center justify-center`}>
                    <div className="text-8xl group-hover:scale-110 transition-transform duration-300">
                      {product.emoji}
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-2xl font-bold text-gray-900 mb-3">{product.title}</h3>
                    <p className="text-gray-600 leading-relaxed mb-4">{product.description}</p>
                    <Button onClick={handleCTA} className="w-full bg-primary hover:bg-primary/90 text-white font-semibold">
                      Mehr erfahren
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default DecorationPage;
