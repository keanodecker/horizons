
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { subscribeToContent, getContent } from '@/lib/supabaseContent.js';

const ContactPage = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  
  const [contactInfo, setContactInfo] = useState({
    contact_phone: '+49 (0) 7821 32 70 82',
    contact_email: 'info@ballonkunst-herzog.de',
    contact_address: 'Kaiserstraße 25\n77933 Lahr'
  });

  useEffect(() => {
    const unsubscribe = subscribeToContent(() => {
      setContactInfo({
        contact_phone: getContent('contact_phone', '+49 (0) 7821 32 70 82'),
        contact_email: getContent('contact_email', 'info@ballonkunst-herzog.de'),
        contact_address: getContent('contact_address', 'Kaiserstraße 25\n77933 Lahr')
      });
    });
    return () => unsubscribe();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      toast({ title: "Erfolg!", description: "Ihre Nachricht wurde erfolgreich gesendet." });
      setFormData({ name: '', email: '', message: '' });
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <>
      <Helmet>
        <title>Kontakt - Ballonkunst Herzog Lahr</title>
        <meta name="description" content="Kontaktieren Sie Ballonkunst Herzog in Lahr." />
      </Helmet>

      <div className="pt-32 pb-20 bg-gray-50 min-h-screen">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Kontaktieren Sie uns
            </motion.h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="relative h-[400px] lg:h-auto bg-gray-100 flex flex-col">
              <div className="flex-grow w-full h-full min-h-[300px]">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2654.688744848484!2d7.8688!3d48.3388!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47912e0000000000%3A0x0!2sKaiserstra%C3%9Fe%2025%2C%2077933%20Lahr%2FSchwarzwald!5e0!3m2!1sde!2sde!4v1600000000000!5m2!1sde!2sde" 
                  width="100%" height="100%" style={{ border: 0 }} allowFullScreen="" loading="lazy" title="Google Maps" className="absolute inset-0"
                ></iframe>
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md p-6 border-t border-gray-200">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Adresse</h4>
                      <p className="text-sm text-gray-600 whitespace-pre-wrap">{contactInfo.contact_address}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="w-5 h-5 text-secondary mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Telefon</h4>
                      <a href={`tel:${contactInfo.contact_phone.replace(/[^0-9+]/g, '')}`} className="text-sm text-gray-600 hover:text-primary transition-colors">
                        {contactInfo.contact_phone}
                      </a>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 sm:col-span-2">
                    <Mail className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-900">E-Mail</h4>
                      <a href={`mailto:${contactInfo.contact_email}`} className="text-sm text-gray-600 hover:text-primary transition-colors">
                        {contactInfo.contact_email}
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-8 md:p-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Schreiben Sie uns</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Name <span className="text-red-500">*</span></Label>
                  <Input id="name" name="name" value={formData.name} onChange={handleChange} required className="text-gray-900" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-Mail <span className="text-red-500">*</span></Label>
                  <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required className="text-gray-900" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="message">Nachricht <span className="text-red-500">*</span></Label>
                  <Textarea id="message" name="message" value={formData.message} onChange={handleChange} rows={5} required className="resize-none text-gray-900" />
                </div>
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 text-lg shadow-lg" disabled={isSubmitting}>
                  {isSubmitting ? 'Wird gesendet...' : <><Send className="w-5 h-5 mr-2" /> Nachricht senden</>}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ContactPage;
