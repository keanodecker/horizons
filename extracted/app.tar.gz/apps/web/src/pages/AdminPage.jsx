
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, Loader2, AlertCircle, LogOut, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/lib/supabaseClient.js';
import { subscribeToContent, getContent } from '@/lib/supabaseContent.js';

const ADMIN_PASSWORD = 'SpecialAdmindashboard';

const ADMIN_SECTIONS = [
  {
    id: 'homepage',
    title: 'Startseite',
    fields: [
      { key: 'hero_title', label: 'Hero Titel', type: 'text' },
      { key: 'hero_subtitle', label: 'Hero Untertitel', type: 'textarea' },
      { key: 'cta_button_1', label: 'Button 1 Text', type: 'text' },
      { key: 'cta_button_2', label: 'Button 2 Text', type: 'text' },
      { key: 'hero_image', label: 'Hero Bild URL', type: 'image' },
    ]
  },
  {
    id: 'about',
    title: 'Über Uns',
    fields: [
      { key: 'about_title', label: 'Titel', type: 'text' },
      { key: 'about_text', label: 'Text', type: 'textarea' },
      { key: 'about_image', label: 'Bild URL', type: 'image' },
    ]
  },
  {
    id: 'dekoration',
    title: 'Dekoration',
    fields: [
      { key: 'dekoration_title', label: 'Titel', type: 'text' },
      { key: 'dekoration_description', label: 'Beschreibung', type: 'textarea' },
      { key: 'dekoration_image', label: 'Bild URL', type: 'image' },
    ]
  },
  {
    id: 'gallery',
    title: 'Galerie',
    fields: [
      { key: 'gallery_images', label: 'Bilder URLs (JSON Array oder kommagetrennt)', type: 'textarea' },
    ]
  },
  {
    id: 'contact',
    title: 'Kontakt',
    fields: [
      { key: 'contact_phone', label: 'Telefon', type: 'text' },
      { key: 'contact_email', label: 'E-Mail', type: 'text' },
      { key: 'contact_address', label: 'Adresse', type: 'textarea' },
    ]
  },
  {
    id: 'services',
    title: 'Services (Anlässe)',
    fields: [
      { key: 'geburtstag_title', label: 'Geburtstag Titel', type: 'text' },
      { key: 'geburtstag_description', label: 'Geburtstag Beschreibung', type: 'textarea' },
      { key: 'geburtstag_image', label: 'Geburtstag Bild URL', type: 'image' },
      { key: 'hochzeit_title', label: 'Hochzeit Titel', type: 'text' },
      { key: 'hochzeit_description', label: 'Hochzeit Beschreibung', type: 'textarea' },
      { key: 'hochzeit_image', label: 'Hochzeit Bild URL', type: 'image' },
      { key: 'geburt-baby_title', label: 'Geburt & Baby Titel', type: 'text' },
      { key: 'geburt-baby_description', label: 'Geburt & Baby Beschreibung', type: 'textarea' },
      { key: 'geburt-baby_image', label: 'Geburt & Baby Bild URL', type: 'image' },
    ]
  }
];

const AdminField = ({ field, sectionId, initialValue }) => {
  const [value, setValue] = useState(initialValue || '');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState(null); // 'success' | 'error' | null

  useEffect(() => {
    setValue(initialValue || '');
  }, [initialValue]);

  const handleSave = async () => {
    setIsSaving(true);
    setSaveStatus(null);
    try {
      let finalValue = value;
      
      // Special handling for gallery JSON array
      if (field.key === 'gallery_images') {
        try {
          // Check if it's already valid JSON
          JSON.parse(value);
        } catch (e) {
          // If not, try to convert comma/newline separated to JSON array
          const urls = value.split(/[\n,]+/).map(s => s.trim()).filter(Boolean);
          finalValue = JSON.stringify(urls);
          setValue(finalValue);
        }
      }

      const { error } = await supabase
        .from('content')
        .upsert({ key: field.key, value: finalValue, section: sectionId }, { onConflict: 'key' });

      if (error) throw error;
      
      setSaveStatus('success');
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (error) {
      console.error('Save error:', error);
      setSaveStatus('error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm mb-4">
      <Label className="text-sm font-semibold text-gray-700 mb-2 block">{field.label}</Label>
      
      {field.type === 'image' && value && (
        <div className="mb-3">
          <img src={value} alt="Preview" className="h-32 w-auto object-cover rounded-md border border-gray-200" />
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
        <div className="flex-1 w-full">
          {field.type === 'textarea' ? (
            <Textarea 
              value={value} 
              onChange={(e) => setValue(e.target.value)} 
              rows={4}
              className="w-full text-gray-900"
            />
          ) : (
            <Input 
              value={value} 
              onChange={(e) => setValue(e.target.value)} 
              className="w-full text-gray-900"
            />
          )}
        </div>
        
        <div className="flex items-center gap-2 shrink-0">
          <Button 
            onClick={handleSave} 
            disabled={isSaving}
            className="bg-pink-600 hover:bg-pink-700 text-white min-w-[120px]"
          >
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
            Speichern
          </Button>
          
          <AnimatePresence mode="wait">
            {saveStatus === 'success' && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="text-green-600 flex items-center text-sm font-medium"
              >
                <CheckCircle2 className="w-5 h-5 mr-1" /> Gespeichert ✓
              </motion.div>
            )}
            {saveStatus === 'error' && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="text-red-600 flex items-center text-sm font-medium"
              >
                <AlertCircle className="w-5 h-5 mr-1" /> Fehler
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

const AdminPage = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeSection, setActiveSection] = useState(ADMIN_SECTIONS[0].id);
  const [contentData, setContentData] = useState({});

  useEffect(() => {
    const session = sessionStorage.getItem('admin_auth');
    if (session === 'true') {
      setIsAuthenticated(true);
    }
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      const unsubscribe = subscribeToContent((data) => {
        const mapped = {};
        Object.values(data).forEach(item => {
          mapped[item.key] = item.value;
        });
        setContentData(mapped);
      });
      return () => unsubscribe();
    }
  }, [isAuthenticated]);

  const handleLogin = (e) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      sessionStorage.setItem('admin_auth', 'true');
      setLoginError('');
    } else {
      setLoginError('Falsches Passwort. Bitte erneut versuchen.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('admin_auth');
    setPassword('');
  };

  if (!isAuthenticated) {
    return (
      <>
        <Helmet>
          <title>Admin Login - Ballonkunst Herzog</title>
          <meta name="robots" content="noindex" />
        </Helmet>
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md border border-gray-100"
          >
            <div className="text-center mb-8">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
              <p className="text-gray-500 text-sm">Bitte loggen Sie sich ein</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="password">Admin Passwort</Label>
                <Input 
                  id="password" 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="text-gray-900"
                  placeholder="••••••••"
                />
                {loginError && <p className="text-red-500 text-sm mt-1">{loginError}</p>}
              </div>
              <Button type="submit" className="w-full bg-pink-600 hover:bg-pink-700 text-white">
                Einloggen
              </Button>
            </form>
          </motion.div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Admin Dashboard - Ballonkunst Herzog</title>
        <meta name="robots" content="noindex" />
      </Helmet>
      
      <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
        {/* Sidebar */}
        <aside className="w-full md:w-64 bg-white border-r border-gray-200 flex flex-col shadow-sm z-20">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">Admin Panel</h2>
          </div>
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {ADMIN_SECTIONS.map((section) => (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  activeSection === section.id 
                    ? 'bg-pink-50 text-pink-700' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                {section.title}
              </button>
            ))}
          </nav>
          <div className="p-4 border-t border-gray-100">
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 transition-colors"
            >
              <LogOut className="w-5 h-5" />
              Ausloggen
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col h-screen overflow-hidden">
          <header className="bg-white border-b border-gray-200 h-16 flex items-center px-8 shadow-sm z-10">
            <h1 className="text-lg font-semibold text-gray-800">
              {ADMIN_SECTIONS.find(s => s.id === activeSection)?.title} bearbeiten
            </h1>
          </header>

          <div className="flex-1 overflow-y-auto p-4 md:p-8">
            <div className="max-w-4xl mx-auto">
              {ADMIN_SECTIONS.find(s => s.id === activeSection)?.fields.map(field => (
                <AdminField 
                  key={field.key} 
                  field={field} 
                  sectionId={activeSection}
                  initialValue={contentData[field.key]} 
                />
              ))}
            </div>
          </div>
        </main>
      </div>
    </>
  );
};

export default AdminPage;
