
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Image as ImageIcon } from 'lucide-react';
import ConsultationCTA from '@/components/ConsultationCTA.jsx';
import { subscribeToContent, getContent } from '@/lib/supabaseContent.js';

const GalleryPage = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [images, setImages] = useState([]);

  useEffect(() => {
    const unsubscribe = subscribeToContent(() => {
      const imagesStr = getContent('gallery_images', '[]');
      try {
        const parsed = JSON.parse(imagesStr);
        if (Array.isArray(parsed)) {
          setImages(parsed.map((url, idx) => ({ id: idx, src: url, title: `Galerie Bild ${idx + 1}` })));
        }
      } catch (e) {
        console.error('Failed to parse gallery images', e);
        setImages([]);
      }
    });
    return () => unsubscribe();
  }, []);

  return (
    <>
      <Helmet>
        <title>Galerie - Ballonkunst Herzog Lahr</title>
        <meta name="description" content="Entdecken Sie unsere Galerie mit Ballondekorationen für jeden Anlass." />
      </Helmet>

      <div className="pt-24 min-h-screen bg-gray-50 flex flex-col">
        <section className="py-12 bg-white border-b border-gray-200">
          <div className="container mx-auto px-4 max-w-7xl text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Unsere Galerie</h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Lassen Sie sich von unseren bisherigen Arbeiten und Ballondekorationen inspirieren.
            </p>
          </div>
        </section>

        <section className="py-12 flex-grow">
          <div className="container mx-auto px-4 max-w-7xl">
            {images.length === 0 ? (
              <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-gray-300">
                <ImageIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-600 mb-2">Keine Bilder gefunden</h3>
                <p className="text-gray-500">Es wurden noch keine Bilder in die Galerie hochgeladen.</p>
              </div>
            ) : (
              <div className="columns-1 sm:columns-2 md:columns-3 lg:columns-4 gap-6 space-y-6">
                <AnimatePresence>
                  {images.map((image) => (
                    <motion.div
                      key={image.id}
                      layout
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.3 }}
                      onClick={() => setSelectedImage(image)}
                      className="relative group break-inside-avoid rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer bg-white"
                    >
                      <img src={image.src} alt={image.title} className="w-full h-auto object-cover" loading="lazy" />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </section>

        <AnimatePresence>
          {selectedImage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedImage(null)}
              className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4 md:p-8"
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="relative max-w-5xl w-full max-h-[90vh] flex flex-col items-center justify-center"
              >
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-12 right-0 md:-right-12 w-10 h-10 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center transition-colors z-50"
                >
                  <X className="w-6 h-6 text-white" />
                </button>
                <img src={selectedImage.src} alt={selectedImage.title} className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl" />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <ConsultationCTA />
      </div>
    </>
  );
};

export default GalleryPage;
